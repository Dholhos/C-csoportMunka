﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using static System.Console;

namespace projekth
{
    internal class World
    {
        private string[,] Maze;
        private int Rows;
        private int Cols;

        public World(string[,] maze)
        {
            Maze = maze;
            Rows = Maze.GetLength(0);
            Cols = Maze.GetLength(1);

        }
        public int GetSuitableEntrance(string[,] maze)
        {
            int exit = 0;
            for (int row = 0; row < maze.GetLength(0); row++)
            {
                string leftCol = maze[row, 0];
                switch (leftCol)
                {
                    case "╠":
                    case "╗":
                    case "╔":
                    case "╬":
                    case "╦":
                    case "║":
                    case "╣":
                    case "═":
                        exit++;
                        break;
                }
                string rightCol = maze[row, maze.GetLength(1) - 1];
                switch (rightCol)
                {
                    case "╠":
                    case "╗":
                    case "╔":
                    case "╬":
                    case "╦":
                    case "║":
                    case "╣":
                    case "═":
                        exit++;
                        break;
                }
            }
            for (int col = 1; col < maze.GetLength(1) - 1; col++)
            {
                string topRow = maze[0, col];
                switch (topRow)
                {
                    case "╠":
                    case "╗":
                    case "╔":
                    case "╬":
                    case "╦":
                    case "║":
                    case "╣":
                    case "═":
                        exit++;
                        break;
                }
                string bottomRow = maze[maze.GetLength(0) - 1, col];
                switch (bottomRow)
                {
                    case "╠":
                    case "╗":
                    case "╔":
                    case "╬":
                    case "╦":
                    case "║":
                    case "╣":
                    case "═":
                        exit++;
                        break;
                }
            }
            return exit;
        }
        static bool IsInvalidElement(char[,] map)
        {
            return true;
        }
        public int GetRoomNumber(string[,] maze)
        {
            int roomNumber = 0;
            foreach (string room in maze)
            {
                if (room == "█")
                {
                    roomNumber++;
                }
            }
            return roomNumber;
        }
        public void Draw()
        {
            for (int y = 0; y < Rows; y++)
            {
                for (int x = 0; x < Cols; x++)
                {
                    string element = Maze[y, x];
                    SetCursorPosition(x, y);
                    Write(element);
                }
            }
            int exitSum = GetSuitableEntrance(Maze);
            int roomSum = GetRoomNumber(Maze);
            Console.WriteLine("");
            Console.WriteLine("Kijáratok száma: "+ exitSum);
            Console.WriteLine("Megtalálható szobák száma:"+ roomSum);
        }
        
        public string ElementAt(int x, int y)
        {
            return Maze[y, x];
        }
        public bool Walkable(int x, int y)
        {
            if (x < 0 || y < 0 || x >= Cols || y >= Rows)
            {
                return false;
            }

            return Maze[y, x] == "╚" || Maze[y, x] == "╔" || Maze[y, x] == "█" || Maze[y, x] == "═" || Maze[y, x] == "╗" || Maze[y, x] == "║" || Maze[y, x] == "╬" || Maze[y, x] == "╩" || Maze[y, x] == "╚" || Maze[y, x] == "╣" || Maze[y, x] == "╠";
        }
    }
}
