﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace projekth
{
    class Program
    {
        static void Main(string[] args)
        {
            Game currentGame = new Game();
            currentGame.Start();
        }
    }
}
